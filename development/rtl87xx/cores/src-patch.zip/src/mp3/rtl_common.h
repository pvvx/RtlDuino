/*
 *  Copyright (C) 
 *
 */

#ifndef __RTL_COMMON_H__
#define __RTL_COMMON_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "c_types.h"

#endif
