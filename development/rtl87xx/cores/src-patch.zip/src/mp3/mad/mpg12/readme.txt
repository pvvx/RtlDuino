Because of size constraints, the option to read mpg1/2 files has been
disabled.