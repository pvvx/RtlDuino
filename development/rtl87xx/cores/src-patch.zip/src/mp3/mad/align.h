//char unalChar(char const *adr);
#define unalChar(x) *(x)
short unalShort(short const *adr);
